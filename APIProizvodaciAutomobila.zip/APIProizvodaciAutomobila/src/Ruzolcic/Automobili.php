<?php

namespace Ruzolcic;

/**
 * @Entity @Table(name="automobili")
 **/


class Automobili
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $markaAutomobila;

    /**
    * @Column(type="string")
    */
    private $proizvodac;

      /**
    * @Column(type="string")
    */
    private $sjediste;

    /**
    * @Column(type="string")
    */
    private $opis;

    public function getSifra(){
      return $this->sifra;
    }
  
    public function setSifra($sifra){
      $this->sifra = $sifra;
    }
  
    public function getMarkaAutomobila(){
      return $this->markaAutomobila;
    }
  
    public function setMarkaAutomobila($markaAutomobila){
      $this->markaAutomobila = $markaAutomobila;
    }
  
    public function getProizvodac(){
      return $this->proizvodac;
    }
  
    public function setProizvodac($proizvodac){
      $this->proizvodac = $proizvodac;
    }
  
    public function getSjediste(){
      return $this->sjediste;
    }
  
    public function setSjediste($sjediste){
      $this->sjediste = $sjediste;
    }
  
    public function getOpis(){
      return $this->opis;
    }
  
    public function setOpis($opis){
      $this->opis = $opis;
    }



  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
