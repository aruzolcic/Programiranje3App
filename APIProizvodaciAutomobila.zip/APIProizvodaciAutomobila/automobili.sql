create database aruzolcic_19 default character set utf8;
use aruzolcic_19;
create table automobili(
    sifra int not null primary key auto_increment,
    markaAutomobila varchar(255) not null,
    proizvodac varchar(100),
    sjediste varchar(100) not null,
    opis text not null
);
insert into automobili(markaAutomobila, proizvodac, sjediste, opis) 
values ("automobil", "automobil", "automobil", "automobil");
