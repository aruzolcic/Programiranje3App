<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Ruzolcic\Automobili;
use Ruzolcic\Projekt;
use Composer\Autoload\ClassLoader;

Flight::route('/', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/aruzolcic_19/automobili.rdf'); 
  $info = $foaf->dump();
  echo "<h2>Ontologija automobila za P3 zadatak:</h2> <br/><br/>" . $info;
});

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Ruzolcic\Automobili');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});
//https://oziz.ffos.hr/nastava20192020/aruzolcic_19/ontologija/search

Flight::route('GET /unesi_podatke', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/aruzolcic_19/automobili.rdf');
  foreach ($foaf->resources() as $resource) {

    $name = $foaf->get($resource, 'foaf:name'); 

    if($name != ''){

      $i = 0;
      $types[] = [];
      $annotations = "";

      $creator = $foaf->get($resource, 'dc:creator');
      $description = $foaf->get($resource, 'dc:description'); 
     

      foreach ($resource->properties() as $key) {
          $annotations .= $key . ': ' . $foaf->get($resource, $key) . "\n"; 
      }

      $automobili = new Automobili();
      $automobili->setPodaci(Flight::request()->data);

      $automobili->setMarkaAutomobila($name); 
      $automobili->setProizvodac($creator);
      $automobili->setSjediste($description);
      $automobili->setOpis($annotations);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($automobili);
      $em->flush();

    }
  }

  echo "U bazu je uspješno unijeta ontologija automobila.";

});

Flight::route('GET /search/@name', function($name){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Ruzolcic\Automobili');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.markaAutomobila LIKE :markaAutomobila')
                        ->setParameter('markaAutomobila', '%'.$name.'%')
                        ->getQuery()
                        ->getResult();  
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Ruzolcic', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();


